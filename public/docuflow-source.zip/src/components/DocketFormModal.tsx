import React, { useState, useEffect } from 'react';
import { 
  X, 
  Plus, 
  Trash2, 
  AlertCircle, 
  Sparkles, 
  Check, 
  Paperclip, 
  Calendar, 
  ArrowDown, 
  ArrowUp,
  FileText,
  Lightbulb,
  HardDrive,
  FolderOpen,
  Settings,
  Layers,
  UploadCloud
} from 'lucide-react';
import { 
  Docket, 
  DocketStep, 
  Priority, 
  DocketStatus,
  DEFAULT_CATEGORIES, 
  DEFAULT_DEPARTMENTS,
  PRIORITY_CONFIG
} from '../types';
import { checkDuplicateDocketCode, suggestNextDocketCode } from '../utils/storage';
import { WorkflowTemplate, loadWorkflowTemplates, saveWorkflowTemplates } from '../utils/templates';
import { saveOfflineFile } from '../utils/fileStorage';
import { LocalFileViewerModal } from './LocalFileViewerModal';
import { TemplateManagerModal } from './TemplateManagerModal';

interface DocketFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (docket: Docket) => void;
  existingDockets: Docket[];
  editingDocket?: Docket | null;
}

export const DocketFormModal: React.FC<DocketFormModalProps> = ({
  isOpen,
  onClose,
  onSave,
  existingDockets,
  editingDocket,
}) => {
  const isEdit = !!editingDocket;

  // Form states
  const [code, setCode] = useState('');
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState(DEFAULT_CATEGORIES[0]);
  const [department, setDepartment] = useState(DEFAULT_DEPARTMENTS[0]);
  const [leadAssignee, setLeadAssignee] = useState('Vũ Văn Thành');
  const [collaboratorsText, setCollaboratorsText] = useState('');
  const [priority, setPriority] = useState<Priority>('high');
  const [status, setStatus] = useState<DocketStatus>('in_progress');
  const [startDate, setStartDate] = useState(new Date().toISOString().split('T')[0]);
  const [dueDate, setDueDate] = useState(
    new Date(Date.now() + 7 * 86400000).toISOString().split('T')[0]
  );
  const [notes, setNotes] = useState('');
  const [tagsText, setTagsText] = useState('');
  const [localFilePath, setLocalFilePath] = useState('');
  const [localFileName, setLocalFileName] = useState('');
  const formFileInputRef = React.useRef<HTMLInputElement>(null);

  // Dynamic templates & Modals
  const [templates, setTemplates] = useState<WorkflowTemplate[]>(loadWorkflowTemplates());
  const [isTemplateManagerOpen, setIsTemplateManagerOpen] = useState(false);
  const [isFileViewerOpen, setIsFileViewerOpen] = useState(false);
  
  // Dynamic Steps
  const [steps, setSteps] = useState<DocketStep[]>([]);
  
  // Real-time duplicate detection state
  const [duplicateWarning, setDuplicateWarning] = useState<{ isDuplicate: boolean; matchedTitle?: string } | null>(null);

  // Initialize or reset form when modal opens
  useEffect(() => {
    if (!isOpen) return;
    setTemplates(loadWorkflowTemplates());

    if (editingDocket) {
      setCode(editingDocket.code);
      setTitle(editingDocket.title);
      setCategory(editingDocket.category);
      setDepartment(editingDocket.department);
      setLeadAssignee(editingDocket.leadAssignee || 'Vũ Văn Thành');
      setCollaboratorsText(editingDocket.collaborators.join(', '));
      setPriority(editingDocket.priority);
      setStatus(editingDocket.status);
      setStartDate(editingDocket.startDate);
      setDueDate(editingDocket.dueDate);
      setNotes(editingDocket.notes || '');
      setTagsText(editingDocket.tags.join(', '));
      setSteps(editingDocket.steps || []);
      setLocalFilePath(editingDocket.localFilePath || '');
      setLocalFileName(editingDocket.localFileName || '');
      setDuplicateWarning(null);
    } else {
      const suggested = suggestNextDocketCode(existingDockets);
      setCode(suggested);
      setTitle('');
      setCategory(DEFAULT_CATEGORIES[0]);
      setDepartment(DEFAULT_DEPARTMENTS[0]);
      setLeadAssignee('Vũ Văn Thành');
      setCollaboratorsText('');
      setPriority('high');
      setStatus('in_progress');
      setStartDate(new Date().toISOString().split('T')[0]);
      setDueDate(new Date(Date.now() + 7 * 86400000).toISOString().split('T')[0]);
      setNotes('');
      setTagsText('');
      setLocalFilePath('');
      setLocalFileName('');
      
      // Default with 2 initial sequential steps
      const cleanPrefix = suggested.replace(/[^a-zA-Z0-9]/g, '');
      setSteps([
        {
          id: `step-${Date.now()}-1`,
          stepCode: `${suggested}-B01`,
          title: 'Tiếp nhận hồ sơ và kiểm tra tính đầy đủ của tài liệu',
          assignee: 'Nguyễn Văn Thành',
          dueDate: new Date(Date.now() + 2 * 86400000).toISOString().split('T')[0],
          status: 'todo',
          priority: 'high',
          order: 1,
          notes: 'Kiểm tra thành phần hồ sơ theo quy định',
        },
        {
          id: `step-${Date.now()}-2`,
          stepCode: `${suggested}-B02`,
          title: 'Thẩm định chuyên môn và lấy ý kiến các đơn vị liên quan',
          assignee: 'Nguyễn Văn Thành',
          dueDate: new Date(Date.now() + 5 * 86400000).toISOString().split('T')[0],
          status: 'todo',
          priority: 'high',
          order: 2,
        },
      ]);
      setDuplicateWarning(null);
    }
  }, [isOpen, editingDocket, existingDockets]);

  // Check duplicate code in real-time as user types
  const handleCodeChange = (newCode: string) => {
    setCode(newCode);
    const result = checkDuplicateDocketCode(newCode, existingDockets, editingDocket?.id);
    if (result.isDuplicate) {
      setDuplicateWarning({
        isDuplicate: true,
        matchedTitle: result.matchedDocket?.title,
      });
    } else {
      setDuplicateWarning(null);
    }
  };

  const handleApplySuggestedCode = () => {
    const nextCode = suggestNextDocketCode(existingDockets);
    setCode(nextCode);
    setDuplicateWarning(null);

    // Update steps codes if they match old prefix pattern
    setSteps((prev) =>
      prev.map((s, idx) => ({
        ...s,
        stepCode: `${nextCode}-B${String(idx + 1).padStart(2, '0')}`,
      }))
    );
  };

  // Add step dynamically
  const handleAddStep = () => {
    const nextIndex = steps.length + 1;
    const baseCode = code.trim() || 'HS-MOI';
    const newStep: DocketStep = {
      id: `step-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      stepCode: `${baseCode}-B${String(nextIndex).padStart(2, '0')}`,
      title: `Bước ${nextIndex}: `,
      assignee: leadAssignee || 'Nguyễn Văn Thành',
      dueDate: dueDate || new Date(Date.now() + 3 * 86400000).toISOString().split('T')[0],
      status: 'todo',
      priority: priority,
      order: nextIndex,
      notes: '',
    };
    setSteps([...steps, newStep]);
  };

  // Remove step
  const handleRemoveStep = (stepId: string) => {
    setSteps(steps.filter((s) => s.id !== stepId));
  };

  // Update step field
  const handleStepFieldChange = (stepId: string, field: keyof DocketStep, value: any) => {
    setSteps(steps.map((s) => (s.id === stepId ? { ...s, [field]: value } : s)));
  };

  // Move step up / down
  const handleMoveStep = (index: number, direction: 'up' | 'down') => {
    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= steps.length) return;
    const reordered = [...steps];
    const [moved] = reordered.splice(index, 1);
    reordered.splice(targetIndex, 0, moved);
    // re-assign order numbers
    setSteps(reordered.map((item, idx) => ({ ...item, order: idx + 1 })));
  };

  // Load a workflow template from dynamic templates list
  const handleLoadTemplate = (templateId: string) => {
    const tpl = templates.find((t) => t.id === templateId);
    if (!tpl) return;

    if (steps.length > 0) {
      const confirm = window.confirm(`Áp dụng "${tpl.name}" sẽ thay thế các bước hiện tại. Tiếp tục?`);
      if (!confirm) return;
    }

    setCategory(tpl.defaultCategory);
    const baseCode = code.trim() || 'HS-2026-TPL';
    const nowMs = Date.now();

    const newSteps: DocketStep[] = tpl.steps.map((s, idx) => ({
      id: `step-${Date.now()}-${idx}`,
      stepCode: `${baseCode}-${s.codeSuffix}`,
      title: s.title,
      assignee: leadAssignee || 'Tôi (Cá nhân)',
      dueDate: new Date(nowMs + s.relativeDays * 86400000).toISOString().split('T')[0],
      status: 'todo',
      priority: s.priority,
      order: idx + 1,
      notes: s.notes || '',
    }));

    setSteps(newSteps);
    // Adjust docket due date to max step dueDate
    const maxDays = Math.max(...tpl.steps.map((s) => s.relativeDays));
    setDueDate(new Date(nowMs + maxDays * 86400000).toISOString().split('T')[0]);
  };

  // Save current form steps as a reusable template
  const handleSaveCurrentStepsAsTemplate = () => {
    if (steps.length === 0) {
      alert('Chưa có bước con nào để lưu thành mẫu quy trình.');
      return;
    }

    const defaultName = title ? `Mẫu: ${title}` : `Quy trình ${category} chuẩn`;
    const tplName = window.prompt('Nhập tên cho Mẫu quy trình mới:', defaultName);
    if (!tplName || !tplName.trim()) return;

    const newTemplate: WorkflowTemplate = {
      id: `tpl-${Date.now()}`,
      name: tplName.trim(),
      description: `Mẫu quy trình tạo từ hồ sơ ${code || 'HS-MỚI'}`,
      defaultCategory: category,
      steps: steps.map((s, idx) => ({
        codeSuffix: `B${String(idx + 1).padStart(2, '0')}`,
        title: s.title,
        relativeDays: (idx + 1) * 2,
        priority: s.priority,
        notes: s.notes || '',
      })),
    };

    const updated = [newTemplate, ...templates];
    saveWorkflowTemplates(updated);
    setTemplates(updated);
    alert(`Đã lưu "${newTemplate.name}" thành công vào danh sách mẫu quy trình! Bạn có thể chọn nạp ở ô chọn bất cứ lúc nào.`);
  };

  // Handle local file picked and save to IndexedDB
  const handleFilePicked = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setLocalFileName(file.name);
    const inferredPath = localFilePath || `D:\\HoSoCongViec\\${code || 'HS-01'}\\${file.name}`;
    if (!localFilePath) {
      setLocalFilePath(inferredPath);
    }

    // Save actual file into IndexedDB for persistent offline access
    await saveOfflineFile(code || 'HS-MOI', file, file.name, inferredPath);
  };

  // Open direct offline file viewer
  const handleOpenOfflineDirect = () => {
    if (!localFilePath && !localFileName) {
      formFileInputRef.current?.click();
      return;
    }
    setIsFileViewerOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!code.trim()) {
      alert('Vui lòng nhập Mã hồ sơ');
      return;
    }
    if (!title.trim()) {
      alert('Vui lòng nhập Tên/Trích yếu hồ sơ');
      return;
    }
    if (duplicateWarning?.isDuplicate) {
      alert('Mã hồ sơ đang bị trùng lặp. Vui lòng sửa lại mã trước khi lưu!');
      return;
    }

    const collaborators = collaboratorsText
      .split(',')
      .map((c) => c.trim())
      .filter(Boolean);

    const tags = tagsText
      .split(',')
      .map((t) => t.trim())
      .filter(Boolean);

    const docketData: Docket = {
      id: editingDocket?.id || `docket-${Date.now()}`,
      code: code.trim().toUpperCase(),
      title: title.trim(),
      category,
      department,
      leadAssignee: leadAssignee.trim(),
      collaborators,
      priority,
      status,
      startDate,
      dueDate,
      notes: notes.trim(),
      tags,
      attachments: editingDocket?.attachments || [
        { id: `att-${Date.now()}`, name: `HoSo_${code.trim()}.pdf`, size: '1.5 MB', addedAt: startDate }
      ],
      steps: steps.map((s, idx) => ({ ...s, order: idx + 1 })),
      localFilePath: localFilePath.trim() || undefined,
      localFileName: localFileName.trim() || undefined,
      createdAt: editingDocket?.createdAt || new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      completedAt: status === 'completed' ? (editingDocket?.completedAt || new Date().toISOString()) : undefined,
    };

    onSave(docketData);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/80 backdrop-blur-md overflow-y-auto">
      {/* 3D Elevated Modal Shell - Distinct Slate Steel Backdrop */}
      <div 
        id="docket-form-modal"
        className="relative w-full max-w-4xl max-h-[92vh] flex flex-col bg-[#e2e8f0] rounded-2xl shadow-[0_25px_60px_-15px_rgba(0,0,0,0.8),0_0_0_3px_#94a3b8] border-2 border-slate-400 overflow-hidden my-auto animate-in fade-in zoom-in-95 duration-200 text-black font-sans"
      >
        {/* Header - 3D Slab */}
        <div className="flex items-center justify-between px-6 py-4 border-b-2 border-slate-400 bg-gradient-to-r from-slate-300 via-slate-200 to-slate-300 shrink-0 shadow-xs">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-600 text-white flex items-center justify-center shadow-md border-2 border-blue-800">
              <FileText className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="text-base font-black text-black tracking-tight flex items-center gap-2">
                <span>{isEdit ? 'Chỉnh sửa Hồ sơ Công việc' : 'Tạo mới Hồ sơ Công việc & Phân rã Bước con'}</span>
                <span className="text-xs font-mono font-black text-black bg-white border-2 border-slate-400 px-2.5 py-0.5 rounded-lg shadow-xs">
                  {code || 'HS-MỚI'}
                </span>
              </h2>
              <p className="text-xs text-slate-800 font-bold mt-0.5">
                Thiết lập thông tin hồ sơ cá nhân, phân rã các bước thực hiện dạng khối 3D trực quan.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-700 hover:text-black hover:bg-slate-300 rounded-xl transition-colors cursor-pointer border border-transparent hover:border-slate-400"
            title="Đóng cửa sổ"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body - Tactile 3D Blocks with Black Text */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-5 bg-[#e2e8f0]">
          {/* Section 1: Thông tin Hồ sơ mẹ - 3D Card Slab */}
          <div className="card-block-3d p-4 sm:p-5 rounded-2xl space-y-4">
            <div className="flex items-center justify-between flex-wrap gap-2 pb-3 border-b-2 border-slate-300">
              <h3 className="text-xs font-black text-black uppercase tracking-wider flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-blue-600" />
                Thông tin chung hồ sơ
              </h3>

              {/* Template quick-picker & Manager */}
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-xs text-black font-extrabold">Nạp mẫu quy trình:</span>
                <select
                  onChange={(e) => {
                    if (e.target.value) handleLoadTemplate(e.target.value);
                    e.target.value = '';
                  }}
                  defaultValue=""
                  className="input-groove-3d text-xs py-1.5 px-3 text-black font-bold rounded-xl cursor-pointer max-w-[220px] sm:max-w-xs truncate"
                >
                  <option value="" disabled>-- Chọn quy trình mẫu ({templates.length}) --</option>
                  {templates.map((tpl) => (
                    <option key={tpl.id} value={tpl.id} className="text-black font-bold">
                      {tpl.name}
                    </option>
                  ))}
                </select>

                <button
                  type="button"
                  onClick={() => setIsTemplateManagerOpen(true)}
                  className="px-2.5 py-1.5 bg-white hover:bg-slate-100 text-black border-2 border-slate-400 rounded-xl font-black text-xs flex items-center gap-1 shadow-2xs cursor-pointer active:translate-y-0.5 shrink-0"
                  title="Chỉnh sửa nội dung các mẫu có sẵn hoặc thêm mẫu quy trình mới"
                >
                  <Settings className="w-3.5 h-3.5 text-blue-700" />
                  <span>Sửa mẫu quy trình</span>
                </button>
              </div>
            </div>

            {/* Duplicate Warning Alert */}
            {duplicateWarning?.isDuplicate && (
              <div className="flex items-start justify-between gap-3 p-3.5 bg-rose-100 border-2 border-rose-400 rounded-xl text-rose-950 text-xs shadow-xs">
                <div className="flex items-start gap-2.5">
                  <AlertCircle className="w-4 h-4 text-rose-700 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-extrabold text-rose-950">Cảnh báo trùng lặp mã:</span> Mã{' '}
                    <strong className="font-mono text-black underline font-black">{code}</strong> đã tồn tại cho hồ sơ:{' '}
                    <span className="italic font-bold">"{duplicateWarning.matchedTitle}"</span>.
                  </div>
                </div>
                <button
                  type="button"
                  onClick={handleApplySuggestedCode}
                  className="px-3 py-1.5 text-xs font-black bg-rose-700 hover:bg-rose-800 text-white rounded-lg shrink-0 transition-colors shadow-xs"
                >
                  Gợi ý mã khác
                </button>
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {/* Code */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-xs font-black text-black uppercase tracking-wide">
                    Mã hồ sơ <span className="text-rose-600">*</span>
                  </label>
                  {!isEdit && (
                    <button
                      type="button"
                      onClick={handleApplySuggestedCode}
                      className="text-[11px] text-blue-700 hover:text-blue-900 hover:underline flex items-center gap-1 font-black"
                    >
                      <Sparkles className="w-3 h-3" />
                      Gợi ý mã mới
                    </button>
                  )}
                </div>
                <input
                  type="text"
                  value={code}
                  onChange={(e) => handleCodeChange(e.target.value)}
                  placeholder="VD: HS-2026-048"
                  className={`input-groove-3d w-full px-3.5 py-2 text-xs font-mono font-black rounded-xl ${
                    duplicateWarning?.isDuplicate ? '!border-rose-600 !bg-rose-50 !text-rose-950' : ''
                  }`}
                  required
                />
              </div>

              {/* Category */}
              <div>
                <label className="block text-xs font-black text-black uppercase tracking-wide mb-1.5">
                  Lĩnh vực / Phân loại
                </label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="input-groove-3d w-full px-3.5 py-2 text-xs font-black rounded-xl cursor-pointer"
                >
                  {DEFAULT_CATEGORIES.map((cat) => (
                    <option key={cat} value={cat} className="text-black font-bold">
                      {cat}
                    </option>
                  ))}
                </select>
              </div>

              {/* Department */}
              <div>
                <label className="block text-xs font-black text-black uppercase tracking-wide mb-1.5">
                  Đơn vị chủ quản / Ban hành
                </label>
                <select
                  value={department}
                  onChange={(e) => setDepartment(e.target.value)}
                  className="input-groove-3d w-full px-3.5 py-2 text-xs font-black rounded-xl cursor-pointer"
                >
                  {DEFAULT_DEPARTMENTS.map((dept) => (
                    <option key={dept} value={dept} className="text-black font-bold">
                      {dept}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Title */}
            <div>
              <label className="block text-xs font-black text-black uppercase tracking-wide mb-1.5">
                Tên hồ sơ / Trích yếu nội dung <span className="text-rose-600">*</span>
              </label>
              <textarea
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Nhập tên trích yếu hồ sơ (VD: Thẩm định hồ sơ thiết kế thi công công trình nâng cấp hạ tầng mạng năm 2026...)"
                rows={2}
                className="input-groove-3d w-full px-3.5 py-2 text-xs font-black rounded-xl placeholder:text-slate-500"
                required
              />
            </div>

            {/* Row: Lead Assignee, Priority, Status, Dates */}
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
              <div>
                <label className="block text-xs font-black text-black uppercase tracking-wide mb-1.5">
                  Người chủ trì xử lý
                </label>
                <input
                  type="text"
                  value={leadAssignee}
                  onChange={(e) => setLeadAssignee(e.target.value)}
                  placeholder="Tôi (Cá nhân)"
                  className="input-groove-3d w-full px-3.5 py-2 text-xs font-black rounded-xl"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-black text-black uppercase tracking-wide mb-1.5">
                  Mức độ ưu tiên
                </label>
                <select
                  value={priority}
                  onChange={(e) => setPriority(e.target.value as Priority)}
                  className="input-groove-3d w-full px-3.5 py-2 text-xs font-black rounded-xl cursor-pointer"
                >
                  <option value="urgent" className="text-rose-700 font-black">Hỏa tốc / Khẩn</option>
                  <option value="high" className="text-amber-700 font-black">Ưu tiên cao</option>
                  <option value="medium" className="text-blue-700 font-black">Bình thường</option>
                  <option value="low" className="text-slate-700 font-black">Thấp</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-black text-black uppercase tracking-wide mb-1.5">
                  Ngày tiếp nhận / Bắt đầu
                </label>
                <input
                  type="date"
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                  className="input-groove-3d w-full px-3.5 py-2 text-xs font-mono font-black rounded-xl"
                />
              </div>

              <div>
                <label className="block text-xs font-black text-black uppercase tracking-wide mb-1.5">
                  Hạn hoàn thành toàn bộ <span className="text-rose-600">*</span>
                </label>
                <input
                  type="date"
                  value={dueDate}
                  onChange={(e) => setDueDate(e.target.value)}
                  className="input-groove-3d w-full px-3.5 py-2 text-xs font-mono font-black rounded-xl"
                  required
                />
              </div>
            </div>

            {/* Row: Notes & Collaborators */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-black text-black uppercase tracking-wide mb-1.5">
                  Người / Đơn vị phối hợp (Ghi chú để nhớ)
                </label>
                <input
                  type="text"
                  value={collaboratorsText}
                  onChange={(e) => setCollaboratorsText(e.target.value)}
                  placeholder="Ghi chú người phối hợp (VD: Anh Minh - Ban CNTT, Chị Lan...)"
                  className="input-groove-3d w-full px-3.5 py-2 text-xs font-black rounded-xl placeholder:text-slate-500"
                />
              </div>

              <div>
                <label className="block text-xs font-black text-black uppercase tracking-wide mb-1.5">
                  Nhãn từ khóa phân loại (Tags)
                </label>
                <input
                  type="text"
                  value={tagsText}
                  onChange={(e) => setTagsText(e.target.value)}
                  placeholder="Thẩm định, CNTT, Khẩn, CĐS..."
                  className="input-groove-3d w-full px-3.5 py-2 text-xs font-black rounded-xl placeholder:text-slate-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-black text-black uppercase tracking-wide mb-1.5">
                Ghi chú tiến độ / Chỉ đạo đặc biệt
              </label>
              <input
                type="text"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Ý kiến chỉ đạo, lưu ý hồ sơ hoặc yêu cầu bổ sung..."
                className="input-groove-3d w-full px-3.5 py-2 text-xs font-black rounded-xl placeholder:text-slate-500"
              />
            </div>
          </div>

          {/* Section 2: Tệp hồ sơ máy tính cá nhân - 3D Block */}
          <div className="card-block-3d p-4 sm:p-5 rounded-2xl space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-xs font-black text-black uppercase tracking-wide flex items-center gap-2">
                <HardDrive className="w-4 h-4 text-blue-700" />
                Đường dẫn hồ sơ gốc trên máy tính cá nhân (Offline Link)
              </label>
              <button
                type="button"
                onClick={handleOpenOfflineDirect}
                className="px-3 py-1 text-[11px] font-black text-white bg-blue-600 hover:bg-blue-700 active:bg-blue-800 border-2 border-blue-900 rounded-full shadow-[0_2px_0_#1e3a8a] flex items-center gap-1 cursor-pointer active:translate-y-0.5"
                title="Mở hồ sơ xem trực tiếp hoặc khởi chạy từ máy tính offline"
              >
                <FolderOpen className="w-3.5 h-3.5" />
                <span>Mở offline trực tiếp</span>
              </button>
            </div>
            <p className="text-xs text-slate-800 font-bold">
              Dán đường dẫn tệp tài liệu hoặc thư mục trên máy (ví dụ: <code className="font-mono text-black font-black bg-slate-200 px-1.5 py-0.5 rounded border border-slate-300">D:\HoSoCongViec\{code || 'HS-01'}\HoSoGoc.pdf</code>), hoặc bấm "Chọn tệp trên máy..." để liên kết trực tiếp.
            </p>

            <div className="flex items-center gap-2 flex-wrap sm:flex-nowrap">
              <input
                type="text"
                value={localFilePath}
                onChange={(e) => setLocalFilePath(e.target.value)}
                placeholder={`D:\\HoSoCongViec\\${code || 'HS-01'}\\HoSoGoc.pdf`}
                className="input-groove-3d flex-1 px-3.5 py-2 text-xs font-mono font-black rounded-xl placeholder:text-slate-500 min-w-[200px]"
              />

              <input
                type="file"
                ref={formFileInputRef}
                className="hidden"
                onChange={handleFilePicked}
              />

              <button
                type="button"
                onClick={() => formFileInputRef.current?.click()}
                className="px-3.5 py-2 text-xs font-black text-slate-800 bg-white hover:bg-slate-100 active:bg-slate-200 border-2 border-slate-400 rounded-xl transition-all flex items-center gap-1.5 shrink-0 cursor-pointer shadow-[0_2px_0_#94a3b8] active:translate-y-0.5"
                title="Chọn tệp từ máy tính để liên kết và lưu bản offline"
              >
                <UploadCloud className="w-4 h-4 text-blue-600" />
                <span>Chọn tệp trên máy...</span>
              </button>

              <button
                type="button"
                onClick={handleOpenOfflineDirect}
                className="px-3.5 py-2 text-xs font-black text-white bg-blue-600 hover:bg-blue-700 active:bg-blue-800 border-2 border-blue-900 rounded-xl transition-all flex items-center gap-1.5 shrink-0 cursor-pointer shadow-[0_3px_0_#1e3a8a] active:translate-y-0.5"
                title="Mở hồ sơ xem trực tiếp hoặc khởi chạy từ máy tính offline"
              >
                <FolderOpen className="w-4 h-4" />
                <span>Mở offline trực tiếp</span>
              </button>
            </div>

            {localFileName && (
              <div className="text-xs text-black flex items-center gap-1.5 pt-1 font-bold">
                <span>Tệp đã chọn:</span>
                <strong className="text-blue-900 font-mono font-black bg-white px-2 py-0.5 rounded border border-slate-300">{localFileName}</strong>
                <button
                  type="button"
                  onClick={handleOpenOfflineDirect}
                  className="text-xs text-blue-700 hover:underline font-black ml-2 cursor-pointer"
                >
                  (Bấm vào đây để mở xem ngay)
                </button>
              </div>
            )}
          </div>

          {/* Section 3: Phân rã các bước công việc con (Sub-steps) - 3D Blocks */}
          <div className="card-block-3d p-4 sm:p-5 rounded-2xl space-y-4">
            <div className="flex items-center justify-between flex-wrap gap-2 pb-3 border-b-2 border-slate-300">
              <div>
                <h3 className="text-xs font-black text-black uppercase tracking-wider flex items-center gap-2">
                  <Check className="w-4 h-4 text-emerald-600" />
                  Nhiệm vụ nhỏ & Phân kỳ các bước ({steps.length} bước)
                </h3>
                <p className="text-xs text-slate-800 font-bold mt-0.5">
                  Thứ tự bước được tự động đánh số dạng khối 3D, không cần nhập mã riêng cho từng bước.
                </p>
              </div>

              <button
                type="button"
                onClick={handleAddStep}
                className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-black text-black bg-white hover:bg-slate-100 border-2 border-slate-400 rounded-xl transition-all shadow-[0_2px_0_#94a3b8] active:translate-y-0.5 cursor-pointer"
              >
                <Plus className="w-4 h-4 text-blue-700" />
                Thêm bước tiếp theo
              </button>
            </div>

            {steps.length === 0 ? (
              <div className="p-8 text-center border-2 border-dashed border-slate-400 rounded-xl text-black font-bold text-xs bg-white">
                Chưa có bước con nào. Bấm "+ Thêm bước tiếp theo" hoặc nạp quy trình mẫu ở trên.
              </div>
            ) : (
              <div className="space-y-3 max-h-80 overflow-y-auto pr-1 custom-mini-scrollbar">
                {steps.map((step, idx) => (
                  <div
                    key={step.id}
                    className="p-3.5 bg-white border-2 border-slate-300 border-b-4 border-b-slate-400 rounded-xl space-y-2.5 shadow-sm"
                  >
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2">
                        {/* Auto-numbered Step Indicator - 3D Pill with Black Text */}
                        <span className="px-3 py-1 text-xs font-mono font-black text-black bg-slate-200 border-2 border-slate-400 rounded-lg shadow-2xs">
                          Bước {idx + 1}
                        </span>
                        <span className="text-xs font-mono font-bold text-slate-600 hidden sm:inline">
                          ({step.stepCode || `${code || 'HS'}-B${String(idx + 1).padStart(2, '0')}`})
                        </span>
                      </div>

                      <div className="flex items-center gap-1">
                        <button
                          type="button"
                          disabled={idx === 0}
                          onClick={() => handleMoveStep(idx, 'up')}
                          className="p-1.5 text-black hover:bg-slate-200 disabled:opacity-20 rounded-lg transition-colors border border-transparent hover:border-slate-400 cursor-pointer"
                          title="Chuyển lên"
                        >
                          <ArrowUp className="w-4 h-4 text-black" />
                        </button>
                        <button
                          type="button"
                          disabled={idx === steps.length - 1}
                          onClick={() => handleMoveStep(idx, 'down')}
                          className="p-1.5 text-black hover:bg-slate-200 disabled:opacity-20 rounded-lg transition-colors border border-transparent hover:border-slate-400 cursor-pointer"
                          title="Chuyển xuống"
                        >
                          <ArrowDown className="w-4 h-4 text-black" />
                        </button>
                        <button
                          type="button"
                          onClick={() => handleRemoveStep(step.id)}
                          className="p-1.5 text-rose-700 hover:text-rose-900 hover:bg-rose-100 border border-transparent hover:border-rose-300 rounded-lg transition-colors cursor-pointer"
                          title="Xóa bước này"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-12 gap-2.5">
                      {/* Title - Pure Black Text */}
                      <div className="md:col-span-6">
                        <input
                          type="text"
                          value={step.title}
                          onChange={(e) => handleStepFieldChange(step.id, 'title', e.target.value)}
                          placeholder="Nội dung nhiệm vụ / bước thực hiện..."
                          className="input-groove-3d w-full px-3 py-1.5 text-xs font-black rounded-lg placeholder:text-slate-500"
                          required
                        />
                      </div>

                      {/* Due Date */}
                      <div className="md:col-span-3">
                        <input
                          type="date"
                          value={step.dueDate}
                          onChange={(e) => handleStepFieldChange(step.id, 'dueDate', e.target.value)}
                          className="input-groove-3d w-full px-2.5 py-1.5 text-xs font-mono font-black rounded-lg"
                        />
                      </div>

                      {/* Priority */}
                      <div className="md:col-span-3">
                        <select
                          value={step.priority}
                          onChange={(e) => handleStepFieldChange(step.id, 'priority', e.target.value as Priority)}
                          className="input-groove-3d w-full px-2.5 py-1.5 text-xs font-black rounded-lg cursor-pointer"
                        >
                          <option value="urgent" className="text-rose-700 font-black">Hỏa tốc</option>
                          <option value="high" className="text-amber-700 font-black">Cao</option>
                          <option value="medium" className="text-blue-700 font-black">Vừa</option>
                          <option value="low" className="text-slate-700 font-black">Thấp</option>
                        </select>
                      </div>
                    </div>

                    {/* Step Notes & Assignee note */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      <input
                        type="text"
                        value={step.notes || ''}
                        onChange={(e) => handleStepFieldChange(step.id, 'notes', e.target.value)}
                        placeholder="Ghi chú chi tiết cho bước này (tùy chọn)..."
                        className="input-groove-3d w-full px-3 py-1.5 text-xs font-bold rounded-lg placeholder:text-slate-500"
                      />
                      <input
                        type="text"
                        value={step.assignee || ''}
                        onChange={(e) => handleStepFieldChange(step.id, 'assignee', e.target.value)}
                        placeholder="Ghi chú người phối hợp nếu có..."
                        className="input-groove-3d w-full px-3 py-1.5 text-xs font-bold rounded-lg placeholder:text-slate-500"
                      />
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Footer Actions - 3D Tactile Buttons */}
          <div className="pt-4 border-t-2 border-slate-400 flex items-center justify-end gap-3 shrink-0">
            <button
              type="button"
              onClick={onClose}
              className="px-5 py-2.5 text-xs font-black text-black bg-white hover:bg-slate-100 rounded-xl transition-all border-2 border-slate-400 shadow-[0_3px_0_#94a3b8] active:translate-y-0.5 cursor-pointer"
            >
              Hủy bỏ
            </button>
            <button
              type="submit"
              disabled={duplicateWarning?.isDuplicate}
              className={`px-6 py-2.5 text-xs font-black text-white rounded-xl transition-all flex items-center gap-2 cursor-pointer ${
                duplicateWarning?.isDuplicate
                  ? 'bg-slate-400 cursor-not-allowed opacity-60'
                  : 'bg-blue-600 hover:bg-blue-700 active:bg-blue-800 border-2 border-blue-900 shadow-[0_4px_0_#1e3a8a] active:translate-y-0.5'
              }`}
            >
              <Check className="w-4 h-4 text-white" />
              <span>{isEdit ? 'Cập nhật hồ sơ' : 'Lưu hồ sơ vào hệ thống'}</span>
            </button>
          </div>
        </form>
      </div>

      {/* Modal Quản lý & Tùy chỉnh Mẫu Quy trình */}
      {isTemplateManagerOpen && (
        <TemplateManagerModal
          isOpen={isTemplateManagerOpen}
          onClose={() => setIsTemplateManagerOpen(false)}
          templates={templates}
          onTemplatesChange={(newTemplates) => setTemplates(newTemplates)}
          onSelectTemplateToLoad={(templateId) => {
            handleLoadTemplate(templateId);
            setIsTemplateManagerOpen(false);
          }}
        />
      )}

      {/* Modal Mở & Xem Hồ sơ Trực tiếp từ máy tính (Offline) */}
      {isFileViewerOpen && (
        <LocalFileViewerModal
          isOpen={isFileViewerOpen}
          onClose={() => setIsFileViewerOpen(false)}
          docketCode={code || 'HS-MOI'}
          docketTitle={title || 'Hồ sơ công việc'}
          localFilePath={localFilePath}
          localFileName={localFileName}
          department={department}
          leadAssignee={leadAssignee}
          dueDate={dueDate}
          steps={steps}
          notes={notes}
          onUpdateFilePath={(newPath, newName) => {
            setLocalFilePath(newPath);
            setLocalFileName(newName);
          }}
        />
      )}
    </div>
  );
};
